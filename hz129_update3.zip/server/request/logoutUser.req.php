<?php
namespace Request;

class logoutUser{
    
    public function __request(){
        
    }
    
}