<?php
namespace Request;

class gameReportError{
    
    public function __request(){}
    
}