<?php
namespace Cls\Bonus;

class ResourceType{
    const Battery = 1;
    const FreeSlotMachineSpin = 2;
    const FreeShop2Refresh = 3;
    const SlotMachineJetons = 4;
}